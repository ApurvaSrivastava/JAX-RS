package wipro.jer.demorest;

import java.net.URI;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;


@Path("/employees")
public class EmpRest {

    private static Map<Integer, Employee> employeesRepository = new HashMap<Integer, Employee>();

// Read - get all the employees
@GET
@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
public Response getEmployees() {
    List<Employee> employees = new ArrayList<Employee>(
            employeesRepository.values());
    GenericEntity<List<Employee>> entity = new GenericEntity<List<Employee>>(
            employees) {
    };
    return Response.ok(entity).build();
}

// Read - get an employee for the given ID
@GET
@Path("/{key}")
@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
public Response getEmployee(@PathParam("key") int key) {

    if (employeesRepository.containsKey(key)) {

        return Response.ok(employeesRepository.get(key)).build();
    } else {

        return Response.status(404).build();
    }
}

// Create - create an employee
@POST
@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
public Response addEmployee(Employee employee, @Context UriInfo uriInfo) {

    if(employee.getId()!=0){
        
        return Response.status(400).build();
    }
    
    int createdEmployeeId = 1;
    
    if(!employeesRepository.isEmpty()){
        
        createdEmployeeId = Collections.max(employeesRepository.keySet()) + 1;
    }
    
    employee.setId(createdEmployeeId);
    employeesRepository.put(createdEmployeeId, employee);
    
    UriBuilder builder = uriInfo.getAbsolutePathBuilder();
    URI createdURI = builder.path(Integer.toString(createdEmployeeId)).build();
    return Response.created(createdURI).build();
}

// Update - updates an existing employee
@PUT
@Path("/{key}")
@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
public Response updateEmployee(@PathParam("key") int key, Employee employee) {

    int status = 0;

    if (employeesRepository.containsKey(key)) {
        // update employeeRepostory
        employeesRepository.put(key, employee);
        status = 204;
    } else {
        status = 404;
    }
    return Response.status(status).build();
}

// Delete - deletes an existing employee
@DELETE
@Path("/{key}")
public Response deleteEmployee(@PathParam("key") int key) {

    employeesRepository.remove(key);
    return Response.noContent().build();
}

// Delete - deletes all the employees
@DELETE
public Response deleteEmployees() {

    employeesRepository.clear();
    return Response.noContent().build();
}
}