package wipro.jer.demorest;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Form;
import javax.ws.rs.core.MediaType;

public class NameClient {
	public static void main(String args[]) {
	Client client=ClientBuilder.newClient();//new client created
	WebTarget service=client.target("http://localhost:8080/demorest");
	Form form4 = new Form();
	form4.param("name", "Apurva");
	String post4=service.
				path("myresource").
				path("convert").
				request(MediaType.TEXT_HTML).
				post(Entity.entity(form4, MediaType.APPLICATION_FORM_URLENCODED_TYPE),String.class);
System.out.println(post4);

}
}