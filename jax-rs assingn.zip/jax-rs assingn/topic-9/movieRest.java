package wipro.jer.demorest;
import java.util.Arrays;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
@Path("movie")
public class movieRest {
@GET
@Produces(MediaType.TEXT_XML)
public List<Movie> getm1(){
	System.out.println("inside movie text xml");
	Movie m1=new Movie();
	m1.setCollection(1102.2f);
	m1.setMactor("mactor1");
	m1.setMid("101");
	m1.setMname("mname1");
	Movie m2=new Movie();
	m2.setCollection(1102.2f);
	m2.setMactor("mactor1");
	m2.setMid("101");
	m2.setMname("mname1");
	List<Movie> m=Arrays.asList(m1,m2);
	return m;
}
@GET
@Produces(MediaType.APPLICATION_XML)
public List<Movie> getm2(){
	System.out.println("inside movie app xml");
	Movie m1=new Movie();
	m1.setCollection(1102.2f);
	m1.setMactor("mactor1");
	m1.setMid("101");
	m1.setMname("mname1");
	Movie m2=new Movie();
	m2.setCollection(1102.2f);
	m2.setMactor("mactor1");
	m2.setMid("101");
	m2.setMname("mname1");
	List<Movie> m=Arrays.asList(m1,m2);
	return m;
}
@GET
@Produces(MediaType.APPLICATION_JSON)
public List<Movie> getm3(){
	System.out.println("inside movie app xml");
	Movie m1=new Movie();
	m1.setCollection(1102.2f);
	m1.setMactor("mactor1");
	m1.setMid("101");
	m1.setMname("mname1");
	Movie m2=new Movie();
	m2.setCollection(1102.2f);
	m2.setMactor("mactor1");
	m2.setMid("101");
	m2.setMname("mname1");
	List<Movie> m=Arrays.asList(m1,m2);
	return m;
}
@GET
@Path("{mid}")
@Produces(MediaType.APPLICATION_XML)
public Movie getm3(@PathParam("mid") String mid){
	System.out.println("inside movie app xml");
	Movie m1=new Movie();
	m1.setCollection(1102.2f);
	m1.setMactor("mactor1");
	m1.setMid("101");
	m1.setMname("mname1");
	Movie m2=new Movie();
	m2.setCollection(1102.2f);
	m2.setMactor("mactor2");
	m2.setMid("102");
	m2.setMname("mname2");
	List<Movie> M=Arrays.asList(m1,m2);
	for(Movie movie : M) {
		if(movie.getMid().equals(mid)) {
			return movie;
		}}
		return new Movie();
}
}
