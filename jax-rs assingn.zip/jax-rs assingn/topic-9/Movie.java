package wipro.jer.demorest;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.json.bind.annotation.JsonbPropertyOrder;
@XmlRootElement
@XmlType(propOrder= {"mid","mname","mactor","collection"})
@JsonbPropertyOrder({"mid","mname","mactor","collection"})
public class Movie {
String mid,mname,mactor;
float collection;
public String getMid() {
	return mid;
}
public void setMid(String mid) {
	this.mid = mid;
}
public String getMname() {
	return mname;
}
public void setMname(String mname) {
	this.mname = mname;
}
public String getMactor() {
	return mactor;
}
public void setMactor(String mactor) {
	this.mactor = mactor;
}
public float getCollection() {
	return collection;
}
public void setCollection(float collection) {
	this.collection = collection;
}

}
