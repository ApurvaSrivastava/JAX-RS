package wipro.jer.demorest;

public class Employee {
private int balance;

public int getBalance() {
	return balance;
}

public void setBalance(int balance) {
	this.balance = balance;
}

}
