package wipro.jer.demorest;

import java.net.URI;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Form;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;

import org.glassfish.jersey.client.ClientConfig;

public class EmpClient {
	public static void main(String[] args) {
		Client client=ClientBuilder.newClient();//new client created
		
		WebTarget service=client.target("http://localhost:8080/demorest");
		Form form1 = new Form();
		form1.param("amount", "10000");
		String post1=service.
				path("emp").
				path("deposit").
				request(MediaType.TEXT_HTML).
				post(Entity.entity(form1, MediaType.APPLICATION_FORM_URLENCODED_TYPE),String.class);
				System.out.println(post1);
			Form form2 = new Form();
			form2.param("amount", "2000");
			String post2=service.
					path("emp").
					path("withdraw").
					request(MediaType.TEXT_HTML).
					post(Entity.entity(form1, MediaType.APPLICATION_FORM_URLENCODED_TYPE),String.class);
					System.out.println(post2);
			
		  Response response=client.
							target("http://localhost:8080/demorest/emp/getbalance").
						    request(MediaType.TEXT_HTML).
						    get();
		  System.out.println(response);

}
}