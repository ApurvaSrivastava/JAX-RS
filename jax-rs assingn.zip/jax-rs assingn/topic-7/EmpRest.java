package wipro.jer.demorest;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("emp")
public class EmpRest {
	Employee e=new Employee();
	@GET
	@Path("getbalance")
    @Produces(MediaType.TEXT_HTML)
    public String getIt() {		
        return "Balance"+e.getBalance();
    }
	  @POST
	  @Path("/withdraw")
	   @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
		@Produces(MediaType.TEXT_HTML)
		public String withdraw(@FormParam("amount") int amount) {  
		  if(amount>e.getBalance())
			  return "sorry your doesn't have enount amount. Opr aborted";
		  else
		  {
			   e.setBalance(e.getBalance()-amount);
			   return "opr performed amount remaining="+e.getBalance();
		  }}
	  
		  @POST
		  @Path("/deposit")
		   @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
			@Produces(MediaType.TEXT_HTML)
			public String deposit(@FormParam("amount") int amount) {  
			e.setBalance(e.getBalance()+amount);
			return "new amount="+e.getBalance();
			  
	    }
}
