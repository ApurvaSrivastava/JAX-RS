package wipro.jer.demorest;

import java.io.IOException;

import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.fasterxml.jackson.databind.ObjectMapper;
@Path("obj")
public class ToJson {
	@POST   
    @Path("/tojson")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_HTML)
	public String tojson(@FormParam("aname") String aname,@FormParam("title") String title,
			@FormParam("singer") String singer) {
    ObjectMapper Obj = new ObjectMapper(); 

	Album a=new Album();
	a.setAname(aname);
	a.setTitle(title); 
	a.setSinger(singer); 


try { 
	String jsonStr = Obj.writeValueAsString(a);
	return jsonStr;
} 

catch (IOException e) { 
    e.printStackTrace();
    return "sorry";
} 


}
}
