package wipro.jer.demorest;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Form;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

public class TojsonClient {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Client client=ClientBuilder.newClient();//new client created
WebTarget service=client.target("http://localhost:8080/demorest");
Form f=new Form();
f.param("singer","s1");
f.param("title", "t1");
f.param("aname", "A");

String post=service.
path("obj").
path("tojson").
request(MediaType.TEXT_HTML).
post(Entity.entity(f, MediaType.APPLICATION_FORM_URLENCODED_TYPE),String.class);
System.out.println(post);
}
}
