package wipro.jer.demorest;

public class Album {
 String aname,title,singer;

public String getAname() {
	return aname;
}

public void setAname(String aname) {
	this.aname = aname;
}

public String getTitle() {
	return title;
}

public void setTitle(String title) {
	this.title = title;
}

public String getSinger() {
	return singer;
}

public void setSinger(String singer) {
	this.singer = singer;
}



}
