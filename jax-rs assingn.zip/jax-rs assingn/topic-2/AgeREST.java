package wipro.jer.demorest;

import java.time.LocalDate;
import java.time.Period;

import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

public class AgeREST {
	 @POST
	    @Path("/age")
	    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
		@Produces(MediaType.TEXT_HTML)
		public String age(@FormParam("year") int year,@FormParam("day") int day,@FormParam("mth") int mth) {
	    	LocalDate today = LocalDate.now();                          //Today's date
	    	LocalDate birthday = LocalDate.of(year, mth, day);  //Birth date
	    	 System.out.println(today);
	    	Period p = Period.between(birthday, today);
	    	 
	    	//Now access the values as below
	    	
	    	return ""+p.getYears();
	    }
}
