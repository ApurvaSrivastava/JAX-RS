package wipro.jer.demorest;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Form;
import javax.ws.rs.core.MediaType;

public class CardClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Client client=ClientBuilder.newClient();//new client created
		WebTarget service=client.target("http://localhost:8080/demorest");
		Form form = new Form();
		form.param("card", "28");
		String postrq=service.
					path("myresource").
					path("card").
					request(MediaType.TEXT_HTML).
					post(Entity.entity(form, MediaType.APPLICATION_FORM_URLENCODED_TYPE),String.class);
	System.out.println(postrq);
	}

}
