package wipro.jer.demorest;

import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

public class CardRest {
	  @POST
	    @Path("/card")
	    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
		@Produces(MediaType.TEXT_HTML)
		public String cards(@FormParam("card") String num) {
	    	int card=num.charAt(num.length()-1)-'0';
	    
	    	if(card%2==0)
	    		return "true";
	    	else
	    		return "false";
	    }
}
