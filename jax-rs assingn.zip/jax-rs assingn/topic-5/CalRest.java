package wipro.jer.demorest;

public class CalRest {

}
