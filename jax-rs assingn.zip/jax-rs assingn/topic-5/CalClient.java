package wipro.jer.demorest;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Form;
import javax.ws.rs.core.MediaType;

public class CalClient {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Client client=ClientBuilder.newClient();
WebTarget service=client.target("http://localhost:8080/demorest");
Form form5 = new Form();
//form fields<num1,num2,opr>
form5.param("num1", "28");
form5.param("num2","23");
form5.param("opr", "sub");
String post5=service.
			path("myresource").
			path("cal").
			request(MediaType.TEXT_HTML).
			post(Entity.entity(form5, MediaType.APPLICATION_FORM_URLENCODED_TYPE),String.class);
}
}